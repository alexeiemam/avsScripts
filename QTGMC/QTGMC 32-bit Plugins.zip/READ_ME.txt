These are the additional plugins and system files needed to use the QTGMC deinterlacing script
There are text instructions in each folder explaining where you need to put the files - please follow these carefully

The original packages for each plugin including any documentation and source code can be found in the "Original Packages" folder

The latest version of the QTGMC script itself can be found here:
http://forum.doom9.org/showthread.php?p=1423459


The plugins below are covered by the GNU GPL v2 license, which is included in a separate text file
MVTools2, FFT3DFilter, Yadif, RemoveGrain, Repair, SSE3Tools and the FFTW libraries

                 
-Vit-